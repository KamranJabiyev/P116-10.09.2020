﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication3.Models
{
    public class Product
    {
        public int Id { get; set; }
        [Required]
        public string Title { get; set; }
        public string Description { get; set; }
        [Required]
        public double Price { get; set; }
        public double Discount { get; set; }
        [Required]
        public int Rate { get; set; }
        public int SaleCount { get; set; }
        [Required]
        public int Count { get; set; }
        public bool Featured { get; set; }
        public double ExTax { get; set; }
        [Required]
        public string Brand { get; set; }
        [Required]
        public string Tag { get; set; }
        public string Code { get; set; }
        public bool IsDeleted { get; set; }
        [NotMapped]
        public IFormFile[] Photos { get; set; }
        public virtual ICollection<ProductImage> ProductImages { get; set; }
        public virtual ICollection<ProductCategory> ProductCategories { get; set; }
    }
}
