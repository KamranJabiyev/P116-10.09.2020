﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication3.DAL;
using WebApplication3.Extentions;
using WebApplication3.Helpers;
using WebApplication3.Models;

namespace WebApplication3.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class ProductController : Controller
    {
        private readonly AppDbContext _db;
        private readonly IWebHostEnvironment _env;
        public ProductController(AppDbContext db, IWebHostEnvironment env)
        {
            _db = db;
            _env = env;
        }
        public IActionResult Index()
        {
            List<Product> products = _db.Products.Where(p => p.IsDeleted == false).Include(p=>p.ProductImages)
                .Include(p => p.ProductCategories).ThenInclude(p => p.Category).ToList();
            return View(products);
        }

        public IActionResult Create()
        {
            ViewBag.MainCtg = _db.Categories.Where(c => c.IsMain && c.IsDeleted == false).ToList();
            int id = _db.Categories.Where(c => c.IsMain && c.IsDeleted == false).FirstOrDefault().Id;
            ViewBag.ChildCtg = _db.Categories.Where(c => c.IsDeleted == false && c.Parent.Id == id).ToList();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Product product,int MainCtgId,int? ChildCtgId)
        {
            ViewBag.MainCtg = _db.Categories.Where(c => c.IsMain && c.IsDeleted == false).ToList();
            int id = _db.Categories.Where(c => c.IsMain && c.IsDeleted == false).FirstOrDefault().Id;
            ViewBag.ChildCtg = _db.Categories.Where(c => c.IsDeleted == false && c.Parent.Id == id).ToList();

            if (!ModelState.IsValid) return View();
            if (ChildCtgId == null)
            {
                ModelState.AddModelError("", "Please select child Category");
                return View();
            }

            bool isExist = _db.Products.Where(p => p.IsDeleted == false).Any(p => p.Title.ToLower() == product.Title.ToLower());
            if (isExist)
            {
                ModelState.AddModelError("Title", "This product already exist");
                return View();
            }

            if (product.Photos == null)
            {
                ModelState.AddModelError("Photos", "Select Photo");
                return View();
            }

            List<ProductCategory> productCategories = new List<ProductCategory>();
            productCategories.Add(new ProductCategory { CategoryId = MainCtgId, ProductId = product.Id });
            productCategories.Add(new ProductCategory { CategoryId = (int)ChildCtgId, ProductId = product.Id });
            product.ProductCategories = productCategories;


            List<ProductImage> productImages = new List<ProductImage>();
            foreach (IFormFile photo in product.Photos)
            {
                if (!photo.IsImage())
                {
                    ModelState.AddModelError("", "If Main Category Created Please Select Photo");
                    return View();
                }
                if (photo.MaxLength(300))
                {
                    ModelState.AddModelError("", "If Main Category Created Please Select Photo,max Length=300 kb");
                    return View();
                }

                string folder = Path.Combine("assets", "images","product");
                string fileName = await photo.SaveImg(_env.WebRootPath, folder);
                ProductImage image = new ProductImage { Image = fileName, ProductId=product.Id};
                productImages.Add(image);
            }
            product.ProductImages = productImages;

            product.IsDeleted = false;
            product.SaleCount = 0;
            product.Code = "abcd" + product.Id.ToString();

            await _db.Products.AddAsync(product);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public IActionResult LoadChildCategory(int? MainCtgId)
        {
            if (MainCtgId == null) return NotFound();
            List<Category> children = _db.Categories.Where(c => c.IsDeleted == false && c.Parent.Id == MainCtgId).ToList();
            return PartialView("_ChildCategoryPartial", children);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteProImage(int? id)
        {
            if (id == null) return NotFound();
            ProductImage productImage =await _db.ProductImages.FindAsync(id);
            if (productImage == null) return NotFound();
            List<ProductImage> allImages = _db.ProductImages.Where(i => i.ProductId == productImage.ProductId).ToList();
            if (allImages.Count() == 1)
            {
                TempData["ImageError"] = "En az bir shekil olmalidr";
                return RedirectToAction("Update", new { Id = productImage.ProductId });
            }

            string folder = Path.Combine("assets", "images", "product");
            Helper.DeleteImage(_env.WebRootPath, folder, productImage.Image);
            _db.ProductImages.Remove(productImage);
            await _db.SaveChangesAsync();

            return RedirectToAction("Update", new { Id = productImage.ProductId });
        }

        public IActionResult Update(int? Id)
        {
            if (Id == null) return NotFound();
            Product product = _db.Products.Where(p => p.IsDeleted == false).Include(p=>p.ProductImages)
                .Include(p=>p.ProductCategories).ThenInclude(p=>p.Category).FirstOrDefault(p => p.Id == Id);
            if (product == null) return NotFound();
            ViewBag.MainCtg = _db.Categories.Where(c => c.IsMain && c.IsDeleted == false).ToList();

            int id = product.ProductCategories.ElementAt(0).Category.Id;
            ViewBag.ChildCtg = _db.Categories.Where(c => c.IsDeleted == false && c.Parent.Id == id).ToList();

            return View(product);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Update(int? id,Product product,int? MainCtgId,int? ChildCtgId)
        {
            if (id == null) return NotFound();

            Product productDb = _db.Products.Where(p => p.IsDeleted == false)
                .Include(p => p.ProductImages).Include(p => p.ProductCategories).ThenInclude(p => p.Category).FirstOrDefault(p => p.Id==id);
            if (productDb == null) return NotFound();

            ViewBag.MainCtg = _db.Categories.Where(c => c.IsMain && c.IsDeleted == false).ToList();
            int Id = productDb.ProductCategories.ElementAt(0).Category.Id;
            ViewBag.ChildCtg = _db.Categories.Where(c => c.IsDeleted == false && c.Parent.Id == Id).ToList();

            Product checkProduct=_db.Products.Where(p=>p.IsDeleted==false)
                .FirstOrDefault(p => p.Title.ToLower() == product.Title.ToLower());

            if (checkProduct != null)
            {
                if(productDb.Title!= checkProduct.Title)
                {
                    ModelState.AddModelError("Title", "This name already exist");
                    return View(productDb);
                }
            }

            if (product.Photos != null)
            {
                foreach (IFormFile photo in product.Photos)
                {
                    if (!photo.IsImage())
                    {
                        ModelState.AddModelError("", "If Main Category Created Please Select Photo");
                        return View();
                    }
                    if (photo.MaxLength(300))
                    {
                        ModelState.AddModelError("", "If Main Category Created Please Select Photo,max Length=300 kb");
                        return View();
                    }

                    string folder = Path.Combine("assets", "images", "product");
                    string fileName = await photo.SaveImg(_env.WebRootPath, folder);
                    ProductImage image = new ProductImage { Image = fileName, ProductId = product.Id };
                    _db.ProductImages.Add(image);
                }
            }

            productDb.Title = product.Title;
            productDb.Price = product.Price;
            productDb.Rate = product.Rate;
            productDb.Count = product.Count;
            //some properties
            productDb.ProductCategories.ElementAt(0).CategoryId = (int)MainCtgId;
            productDb.ProductCategories.ElementAt(1).CategoryId = (int)ChildCtgId;

            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}